alter table EVENT_TRIGGER add PATH TEXT;
