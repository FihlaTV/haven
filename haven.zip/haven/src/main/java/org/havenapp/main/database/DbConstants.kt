package org.havenapp.main.database

/**
 * Created by Arka Prava Basu <arkaprava94@gmail.com> on 19/10/18.
 */

const val DB_INIT_START = 0x1
const val DB_INIT_END = 0x2

const val DB_INIT_STATUS = "db_init_status"
